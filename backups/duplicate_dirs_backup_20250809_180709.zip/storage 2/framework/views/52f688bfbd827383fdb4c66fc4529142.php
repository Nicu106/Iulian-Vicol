<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Auto Premium'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', 'Auto Premium - Dealer auto de încredere'); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS & Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-icons.css')); ?>">

    <!-- Global minimal styles (reset + tokens + base) -->
    <link rel="stylesheet" href="<?php echo e(asset('css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tokens.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">

    <!-- Shared component styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/components/navigation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components/footer.css')); ?>">

    <!-- Route/page specific styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="<?php echo $__env->yieldContent('page-class'); ?>">
    <!-- Navigation -->
    <nav class="ap-navbar">
        <div class="container ap-navbar-container">
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
                <span class="ap">AP</span><span class="tech">TECH</span>
            </a>
            
            <div class="ap-nav">
            <a href="<?php echo e(route('home')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                    Acasă
                </a>
            <a href="<?php echo e(route('catalog')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('vehicles.*') || request()->routeIs('catalog') ? 'active' : ''); ?>">
                    Catalog
                </a>
                <a href="<?php echo e(route('about')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
                    Despre
                </a>
                <a href="<?php echo e(route('contact')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                    Contact
                </a>
            <a href="<?php echo e(route('catalog')); ?>" class="ap-nav-cta">
                    Vezi Catalogul
                </a>
            </div>

            <button class="ap-mobile-menu-btn" id="mobile-menu-button">
                <i class="bi bi-list"></i>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div class="ap-mobile-menu" id="mobile-menu">
            <a href="<?php echo e(route('home')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                Acasă
            </a>
            <a href="<?php echo e(route('catalog')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('vehicles.*') || request()->routeIs('catalog') ? 'active' : ''); ?>">
                Catalog
            </a>
            <a href="<?php echo e(route('about')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
                Despre
            </a>
            <a href="<?php echo e(route('contact')); ?>" class="ap-nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                Contact
            </a>
            <a href="<?php echo e(route('catalog')); ?>" class="ap-nav-cta">
                Vezi Catalogul
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer Component -->
    <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>

    <!-- Navigation JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const backToTopBtn = document.getElementById('back-to-top');
            
            // Mobile Menu Toggle
            mobileMenuBtn.addEventListener('click', function() {
                mobileMenu.classList.toggle('active');
                mobileMenuBtn.classList.toggle('active');
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('.ap-navbar')) {
                    mobileMenu.classList.remove('active');
                    mobileMenuBtn.classList.remove('active');
                }
            });

            // Back to Top functionality
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    backToTopBtn.classList.add('visible');
                } else {
                    backToTopBtn.classList.remove('visible');
                }
            });

            backToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Newsletter form handling
            const newsletterForm = document.querySelector('.newsletter-form');
            if (newsletterForm) {
                newsletterForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const email = this.querySelector('input[type="email"]').value;
                    
                    // Here you can add AJAX call to handle newsletter subscription
                    alert('Mulțumim pentru abonare! Vei primi noutățile în curând.');
                    this.reset();
                });
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
      window.apTrack = function(eventName, payload) {
        try { console.debug('[apTrack]', eventName, payload || {}); } catch (_) {}
        if (window.apAnalytics && typeof window.apAnalytics.track === 'function') {
          window.apAnalytics.track(eventName, payload || {});
        }
      };
      document.addEventListener('click', function(e){
        const el = e.target.closest('[data-analytics]');
        if (!el) return;
        const name = el.getAttribute('data-analytics');
        let payload = {};
        try { payload = JSON.parse(el.getAttribute('data-analytics-payload') || '{}'); } catch(_){ payload = {}; }
        window.apTrack(name, payload);
      });
    </script>
</body>
</html><?php /**PATH /Users/nicucociorva/Documents/Job/IulianVicol/auto-ecommerce/resources/views/layouts/app.blade.php ENDPATH**/ ?>
<footer class="footer">
    <div class="container">
        <!-- Main Footer Content -->
        <div class="footer-main">
            <div class="row">
                <!-- Company Info -->
                <div class="col-lg-4 col-md-6 mb-3">
                    <div class="footer-section">
                        <div class="footer-logo mb-3">
                            <span class="ap">AP</span><span class="tech">TECH</span>
                        </div>
                        <p class="footer-description">
                            Dealer auto de încredere cu peste 15 ani de experiență. Oferim vehicule de calitate și servicii profesionale.
                        </p>
                        <div class="footer-social">
                            <a href="#" class="social-link" aria-label="Facebook">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <a href="#" class="social-link" aria-label="Instagram">
                                <i class="bi bi-instagram"></i>
                            </a>
                            <a href="#" class="social-link" aria-label="LinkedIn">
                                <i class="bi bi-linkedin"></i>
                            </a>
                            <a href="#" class="social-link" aria-label="YouTube">
                                <i class="bi bi-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6 mb-3">
                    <div class="footer-section">
                        <h5 class="footer-title">Link-uri Rapide</h5>
                        <ul class="footer-links">
                            <li><a href="<?php echo e(route('home')); ?>">Acasă</a></li>
                            <li><a href="<?php echo e(route('vehicles.index')); ?>">Catalog</a></li>
                            <li><a href="<?php echo e(route('about')); ?>">Despre Noi</a></li>
                            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                            <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Services -->
                <div class="col-lg-2 col-md-6 mb-3">
                    <div class="footer-section">
                        <h5 class="footer-title">Servicii</h5>
                        <ul class="footer-links">
                            <li><a href="#">Vânzare Auto</a></li>
                            <li><a href="#">Service Tehnic</a></li>
                            <li><a href="#">Finanțare</a></li>
                            <li><a href="#">Asigurări</a></li>
                            <li><a href="#">Test Drive</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-lg-4 col-md-6 mb-3">
                    <div class="footer-section">
                        <h5 class="footer-title">Contact</h5>
                        <div class="contact-info">
                            <div class="contact-item">
                                <i class="bi bi-geo-alt"></i>
                                <div>
                                    <strong>Adresa:</strong><br>
                                    Strada Exemplu, Nr. 123<br>
                                    București, România
                                </div>
                            </div>
                            <div class="contact-item">
                                <i class="bi bi-telephone"></i>
                                <div>
                                    <strong>Telefon:</strong><br>
                                    <a href="tel:+40123456789">+40 123 456 789</a>
                                </div>
                            </div>
                            <div class="contact-item">
                                <i class="bi bi-envelope"></i>
                                <div>
                                    <strong>Email:</strong><br>
                                    <a href="mailto:contact@autopremium.ro">contact@autopremium.ro</a>
                                </div>
                            </div>
                            <div class="contact-item">
                                <i class="bi bi-clock"></i>
                                <div>
                                    <strong>Program:</strong><br>
                                    Luni-Vineri: 9:00-18:00<br>
                                    Sâmbătă: 9:00-14:00
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- Bottom Footer -->
        <div class="footer-bottom">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <p class="copyright">
                        © <?php echo e(date('Y')); ?> Auto Premium. Toate drepturile rezervate.
                    </p>
                </div>
                <div class="col-lg-6">
                    <ul class="footer-legal">
                        <li><a href="<?php echo e(route('terms')); ?>">Termeni și Condiții</a></li>
                        <li><a href="#">Politica de Confidențialitate</a></li>
                        <li><a href="#">Cookies</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="back-to-top" aria-label="Înapoi sus">
        <i class="bi bi-arrow-up"></i>
    </button>
</footer>
<?php /**PATH /Users/nicucociorva/Documents/Job/IulianVicol/auto-ecommerce/resources/views/components/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Catalog Auto - Auto Premium'); ?>
<?php $__env->startSection('description', 'Descoperă catalogul nostru complet de vehicule. Filtrează după marcă, preț, an și multe altele.'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/pages/catalog.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-class', 'page-catalog'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Debug Section -->
    <div class="container mt-4">
        <div class="alert alert-info">
            <strong>Debug Info:</strong> 
            Vehicule în baza de date: <?php echo e($vehicles->count()); ?> | 
            Total: <?php echo e($vehicles->total()); ?> |
            Pagina: <?php echo e($vehicles->currentPage()); ?>

        </div>
    </div>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">
                    La Noi Găsești Orice
                </h1>
                <p class="hero-subtitle">
                    De la mașini de oraș la SUV-uri de lux, avem exact ce cauți
                </p>
            </div>
        </div>
    </section>

    <!-- Catalog Section -->
    <section class="catalog-section">
        <div class="container">
            <div class="catalog-container">
                <!-- Left Sidebar - Advanced Filters -->
                <div class="catalog-filters">
                    <aside class="filters-sidebar">
                        <div class="filters-header">
                            <h3 class="filters-title">Filtre Avansate</h3>
                            <button id="clear-filters" class="btn-reset">
                                <i class="bi bi-arrow-clockwise"></i> Resetează
                            </button>
                        </div>

                        <form id="vehicle-filters">
                            <!-- Brand Filter -->
                            <div class="filter-group">
                                <label class="filter-label">Marcă</label>
                                <select name="brands[]" class="form-select" multiple>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand); ?>" 
                                                <?php echo e(in_array($brand, request('brands', [])) ? 'selected' : ''); ?>>
                                            <?php echo e($brand); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="filter-chips" id="brand-chips"></div>
                            </div>

                            <!-- Price Range -->
                            <div class="filter-group">
                                <label class="filter-label">Preț (€)</label>
                                <div class="price-range">
                                    <input type="number" name="min_price" placeholder="Min" 
                                           value="<?php echo e(request('min_price')); ?>" class="form-control">
                                    <span class="price-separator">-</span>
                                    <input type="number" name="max_price" placeholder="Max" 
                                           value="<?php echo e(request('max_price')); ?>" class="form-control">
                                </div>
                            </div>

                            <!-- Year Range -->
                            <div class="filter-group">
                                <label class="filter-label">An</label>
                                <div class="year-range">
                                    <select name="min_year" class="form-select">
                                        <option value="">De la</option>
                                        <?php for($year = date('Y'); $year >= 1990; $year--): ?>
                                            <option value="<?php echo e($year); ?>" <?php echo e(request('min_year') == $year ? 'selected' : ''); ?>>
                                                <?php echo e($year); ?>

                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <select name="max_year" class="form-select">
                                        <option value="">Până la</option>
                                        <?php for($year = date('Y'); $year >= 1990; $year--): ?>
                                            <option value="<?php echo e($year); ?>" <?php echo e(request('max_year') == $year ? 'selected' : ''); ?>>
                                                <?php echo e($year); ?>

                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>

                            <!-- Fuel Type -->
                            <div class="filter-group">
                                <label class="filter-label">Combustibil</label>
                                <select name="fuel_type" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Benzină" <?php echo e(request('fuel_type') == 'Benzină' ? 'selected' : ''); ?>>Benzină</option>
                                    <option value="Diesel" <?php echo e(request('fuel_type') == 'Diesel' ? 'selected' : ''); ?>>Diesel</option>
                                    <option value="Electric" <?php echo e(request('fuel_type') == 'Electric' ? 'selected' : ''); ?>>Electric</option>
                                    <option value="Hibrid" <?php echo e(request('fuel_type') == 'Hibrid' ? 'selected' : ''); ?>>Hibrid</option>
                                </select>
                            </div>

                            <!-- Transmission -->
                            <div class="filter-group">
                                <label class="filter-label">Transmisie</label>
                                <select name="transmission" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Manuală" <?php echo e(request('transmission') == 'Manuală' ? 'selected' : ''); ?>>Manuală</option>
                                    <option value="Automată" <?php echo e(request('transmission') == 'Automată' ? 'selected' : ''); ?>>Automată</option>
                                </select>
                            </div>

                            <!-- Vehicle Type -->
                            <div class="filter-group">
                                <label class="filter-label">Tip Vehicul</label>
                                <select name="vehicle_type" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="SUV" <?php echo e(request('vehicle_type') == 'SUV' ? 'selected' : ''); ?>>SUV</option>
                                    <option value="Sedan" <?php echo e(request('vehicle_type') == 'Sedan' ? 'selected' : ''); ?>>Sedan</option>
                                    <option value="Hatchback" <?php echo e(request('vehicle_type') == 'Hatchback' ? 'selected' : ''); ?>>Hatchback</option>
                                    <option value="Break" <?php echo e(request('vehicle_type') == 'Break' ? 'selected' : ''); ?>>Break</option>
                                    <option value="Coupe" <?php echo e(request('vehicle_type') == 'Coupe' ? 'selected' : ''); ?>>Coupe</option>
                                </select>
                            </div>

                            <!-- Color -->
                            <div class="filter-group">
                                <label class="filter-label">Culoare</label>
                                <select name="color" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Alb" <?php echo e(request('color') == 'Alb' ? 'selected' : ''); ?>>Alb</option>
                                    <option value="Negru" <?php echo e(request('color') == 'Negru' ? 'selected' : ''); ?>>Negru</option>
                                    <option value="Gri" <?php echo e(request('color') == 'Gri' ? 'selected' : ''); ?>>Gri</option>
                                    <option value="Albastru" <?php echo e(request('color') == 'Albastru' ? 'selected' : ''); ?>>Albastru</option>
                                    <option value="Roșu" <?php echo e(request('color') == 'Roșu' ? 'selected' : ''); ?>>Roșu</option>
                                    <option value="Verde" <?php echo e(request('color') == 'Verde' ? 'selected' : ''); ?>>Verde</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Aplică Filtrele
                            </button>
                        </form>
                    </aside>
                </div>

                <!-- Right Content - Vehicle Grid -->
                <div class="catalog-content">
                    <!-- Results Header -->
                    <div class="results-header">
                        <div>
                            <div class="results-count"><?php echo e($vehicles->count()); ?> vehicule găsite</div>
                            <div class="results-subtitle">Rezultate pentru criteriile tale de căutare</div>
                        </div>
                         <div>
                             <select class="form-select sort-select">
                                 <option value="newest" <?php echo e(request('sort')=='newest' ? 'selected' : ''); ?>>Cele mai noi</option>
                                 <option value="oldest" <?php echo e(request('sort')=='oldest' ? 'selected' : ''); ?>>Cele mai vechi</option>
                                 <option value="price_asc" <?php echo e(request('sort')=='price_asc' ? 'selected' : ''); ?>>Preț crescător</option>
                                 <option value="price_desc" <?php echo e(request('sort')=='price_desc' ? 'selected' : ''); ?>>Preț descrescător</option>
                             </select>
                         </div>
                    </div>

                    <!-- Vehicle Grid -->
                    <div class="vehicle-grid">
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="vehicle-grid-item">
                                <div class="vehicle-card">
                                    <div class="vehicle-image-container">
                                        <img src="<?php echo e($vehicle->primaryImage?->image_url ?? 'https://via.placeholder.com/300x200?text=No+Image'); ?>" 
                                             alt="<?php echo e($vehicle->title); ?>" class="vehicle-image">
                                        
                                        <?php if($vehicle->is_featured): ?>
                                            <div class="vehicle-badge">
                                                <i class="bi bi-star-fill"></i> Featured
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if($vehicle->is_available): ?>
                                            <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-success);">
                                                <i class="bi bi-check-circle"></i> Disponibil
                                            </div>
                                        <?php else: ?>
                                            <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-secondary);">
                                                <i class="bi bi-x-circle"></i> Vândut
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="vehicle-content">
                                        <h5 class="vehicle-title"><?php echo e($vehicle->title); ?></h5>
                                        <div class="vehicle-price"><?php echo e($vehicle->formatted_price); ?></div>
                                        
                                        <div class="vehicle-details">
                                            <div class="vehicle-detail">
                                                <i class="bi bi-calendar"></i>
                                                <div class="vehicle-detail-label">An</div>
                                                <div class="vehicle-detail-value"><?php echo e($vehicle->year); ?></div>
                                            </div>
                                            <div class="vehicle-detail">
                                                <i class="bi bi-speedometer2"></i>
                                                <div class="vehicle-detail-label">Km</div>
                                                <div class="vehicle-detail-value"><?php echo e($vehicle->formatted_mileage); ?></div>
                                            </div>
                                            <div class="vehicle-detail">
                                                <i class="bi bi-fuel-pump"></i>
                                                <div class="vehicle-detail-label">Combustibil</div>
                                                <div class="vehicle-detail-value"><?php echo e($vehicle->fuel_type); ?></div>
                                            </div>
                                        </div>

                                        <?php if($vehicle->features): ?>
                                            <div class="vehicle-features">
                                                <?php $__currentLoopData = array_slice($vehicle->features, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="feature-tag"><?php echo e($feature); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($vehicle->features) > 3): ?>
                                                    <span class="feature-tag">+<?php echo e(count($vehicle->features) - 3); ?> mai multe</span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                        <div class="vehicle-actions">
                                            <a href="<?php echo e(route('vehicles.show', $vehicle)); ?>" class="btn-view-details">
                                                <i class="bi bi-eye"></i> Vezi Detalii
                                            </a>
                                            <button class="btn-favorite" onclick="toggleFavorite(<?php echo e($vehicle->id); ?>)">
                                                <i class="bi bi-heart"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Pagination -->
                    <?php if($vehicles->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($vehicles->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Advanced Filter Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit form when filters change
    const filterForm = document.getElementById('vehicle-filters');
    const filterInputs = filterForm.querySelectorAll('input, select');
    
    filterInputs.forEach(input => {
        input.addEventListener('change', function() {
            setTimeout(() => {
                filterForm.submit();
            }, 500);
        });
    });

    // Clear filters functionality
    const clearFiltersBtn = document.getElementById('clear-filters');
    clearFiltersBtn.addEventListener('click', function() {
        window.location.href = '<?php echo e(route("vehicles.index")); ?>';
    });

    // Sort functionality
    const sortSelect = document.querySelector('.sort-select');
    sortSelect.addEventListener('change', function() {
        const url = new URL(window.location);
        url.searchParams.set('sort', this.value);
        window.location = url;
    });

    // Filter chips functionality
    updateFilterChips();
});

function updateFilterChips() {
    const urlParams = new URLSearchParams(window.location.search);
    const chipsContainer = document.getElementById('brand-chips');
    
    if (chipsContainer) {
        chipsContainer.innerHTML = '';
        
        const brands = urlParams.getAll('brands[]');
        brands.forEach(brand => {
            const chip = document.createElement('div');
            chip.className = 'filter-chip';
            chip.innerHTML = `
                ${brand}
                <button class="remove-chip" onclick="removeFilter('brands[]', '${brand}')">
                    <i class="bi bi-x"></i>
                </button>
            `;
            chipsContainer.appendChild(chip);
        });
    }
}

function removeFilter(param, value) {
    const url = new URL(window.location);
    const values = url.searchParams.getAll(param);
    const newValues = values.filter(v => v !== value);
    
    url.searchParams.delete(param);
    newValues.forEach(v => url.searchParams.append(param, v));
    
    window.location = url;
}

function toggleFavorite(vehicleId) {
    // Add favorite functionality
    const btn = event.target.closest('.btn-favorite');
    const icon = btn.querySelector('i');
    
    if (icon.classList.contains('bi-heart')) {
        icon.classList.remove('bi-heart');
        icon.classList.add('bi-heart-fill');
        btn.style.background = 'var(--gradient-secondary)';
    } else {
        icon.classList.remove('bi-heart-fill');
        icon.classList.add('bi-heart');
        btn.style.background = 'var(--gradient-primary)';
    }
}
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nicucociorva/Documents/Job/IulianVicol/auto-ecommerce/resources/views/vehicles/index.blade.php ENDPATH**/ ?>
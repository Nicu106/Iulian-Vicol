<?php $__env->startSection('title', 'Auto Premium - Dealer Auto de Încredere'); ?>
<?php $__env->startSection('description', 'Auto Premium - Dealer auto cu peste 15 ani de experiență în industria auto românească. Oferim mașini de calitate și service tehnic profesionist.'); ?>

<?php $__env->startSection('page-class', 'page-home'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="h3">Acasă</h1>
  <p>Conținutul va fi adăugat ulterior.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/nicucociorva/Documents/Job/IulianVicol/auto-ecommerce/resources/views/home.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('title', 'Contact - Auto Premium')
@section('description', 'Contactează-ne pentru orice întrebări despre vehiculele noastre sau pentru a programa o vizită.')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/pages/contact.css') }}">
@endpush

@section('page-class', 'page-contact')

@section('content')
    <!-- Contact Page Header -->
    <section class="contact-header py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div class="container mx-auto px-6">
            <div class="text-center max-w-4xl mx-auto">
                <div class="header-badge mb-6">
                    <span class="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-full font-medium">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                        </svg>
                        Suntem aici pentru tine
                    </span>
                </div>
                
                <h1 class="header-title text-4xl md:text-6xl font-black text-gray-900 leading-tight mb-6">
                    Să Discutăm
                </h1>
                <p class="header-subtitle text-xl text-gray-600 font-light mb-8 max-w-2xl mx-auto">
                    Echipa noastră de experți este pregătită să te ajute să găsești vehiculul perfect. 
                    Contactează-ne pentru orice întrebări.
                </p>
                
                <div class="header-stats grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
                    <div class="stat-item bg-white rounded-xl p-6 shadow-sm">
                        <div class="stat-number text-3xl font-bold text-blue-600 mb-2">24/7</div>
                        <div class="stat-label text-gray-600">Suport Disponibil</div>
                    </div>
                    <div class="stat-item bg-white rounded-xl p-6 shadow-sm">
                        <div class="stat-number text-3xl font-bold text-blue-600 mb-2">15min</div>
                        <div class="stat-label text-gray-600">Răspuns Rapid</div>
                    </div>
                    <div class="stat-item bg-white rounded-xl p-6 shadow-sm">
                        <div class="stat-number text-3xl font-bold text-blue-600 mb-2">100%</div>
                        <div class="stat-label text-gray-600">Satisfacție</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section class="contact-form-section py-20 bg-white">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
                
                <!-- Contact Form -->
                <div class="contact-form-card">
                    <div class="form-header mb-10">
                        <h2 class="form-title text-3xl font-bold text-gray-900 mb-4">
                            Trimite-ne un Mesaj
                        </h2>
                        <p class="form-subtitle text-gray-600 text-lg">
                            Completează formularul de mai jos și te vom contacta în cel mai scurt timp.
                        </p>
                    </div>
                    
                    @if(session('success'))
                        <div class="success-message mb-8">
                            <div class="flex items-center p-4 bg-green-50 border border-green-200 rounded-xl">
                                <svg class="w-6 h-6 text-green-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-green-800 font-medium">{{ session('success') }}</span>
                            </div>
                        </div>
                    @endif

                    <form action="{{ route('contact.store') }}" method="POST" class="contact-form">
                        @csrf
                        
                        <div class="form-grid grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                            <div class="form-group">
                                <label for="name" class="form-label">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                    Nume Complet *
                                </label>
                                <input type="text" id="name" name="name" required
                                       value="{{ old('name') }}"
                                       class="form-input"
                                       placeholder="Introdu numele tău complet">
                                @error('name')
                                    <p class="error-message">{{ $message }}</p>
                                @enderror
                            </div>
                            
                            <div class="form-group">
                                <label for="email" class="form-label">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                    </svg>
                                    Email *
                                </label>
                                <input type="email" id="email" name="email" required
                                       value="{{ old('email') }}"
                                       class="form-input"
                                       placeholder="email@exemplu.com">
                                @error('email')
                                    <p class="error-message">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="form-grid grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                            <div class="form-group">
                                <label for="phone" class="form-label">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                    </svg>
                                    Telefon
                                </label>
                                <input type="tel" id="phone" name="phone"
                                       value="{{ old('phone') }}"
                                       class="form-input"
                                       placeholder="+40 123 456 789">
                                @error('phone')
                                    <p class="error-message">{{ $message }}</p>
                                @enderror
                            </div>
                            
                            <div class="form-group">
                                <label for="subject" class="form-label">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                    </svg>
                                    Subiect *
                                </label>
                                <input type="text" id="subject" name="subject" required
                                       value="{{ old('subject') }}"
                                       class="form-input"
                                       placeholder="Despre ce vrei să discutăm?">
                                @error('subject')
                                    <p class="error-message">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="form-group mb-8">
                            <label for="message" class="form-label">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                </svg>
                                Mesaj *
                            </label>
                            <textarea id="message" name="message" required rows="6"
                                      class="form-textarea"
                                      placeholder="Scrie mesajul tău aici...">{{ old('message') }}</textarea>
                            @error('message')
                                <p class="error-message">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <button type="submit" class="submit-button">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                            </svg>
                            Trimite Mesajul
                        </button>
                    </form>
                </div>
                
                <!-- Contact Information -->
                <div class="contact-info">
                    <div class="info-header mb-10">
                        <h2 class="info-title text-3xl font-bold text-gray-900 mb-4">
                            Informații de Contact
                        </h2>
                        <p class="info-subtitle text-gray-600 text-lg">
                            Găsește-ne la adresa noastră sau contactează-ne prin orice metodă preferată.
                        </p>
                    </div>
                    
                    <div class="info-cards space-y-8">
                        <!-- Address Card -->
                        <div class="info-card">
                            <div class="card-icon">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                </svg>
                            </div>
                            <div class="card-content">
                                <h3 class="card-title">Adresa</h3>
                                <div class="card-text">
                                    <p>Strada Exemplu, Nr. 123</p>
                                    <p>Sector 1, București</p>
                                    <p>România</p>
                                </div>
                                <a href="#" class="card-link">Vezi pe hartă</a>
                            </div>
                        </div>
                        
                        <!-- Phone Card -->
                        <div class="info-card">
                            <div class="card-icon">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                </svg>
                            </div>
                            <div class="card-content">
                                <h3 class="card-title">Telefon</h3>
                                <div class="card-badge">Disponibil 24/7</div>
                                <div class="card-text">
                                    <a href="tel:+40123456789" class="phone-link">+40 123 456 789</a>
                                    <a href="tel:+40123456788" class="phone-link">+40 123 456 788</a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Email Card -->
                        <div class="info-card">
                            <div class="card-icon">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                            <div class="card-content">
                                <h3 class="card-title">Email</h3>
                                <div class="card-badge">Răspuns în 15 min</div>
                                <div class="card-text">
                                    <a href="mailto:contact@autopremium.ro" class="phone-link">contact@autopremium.ro</a>
                                    <a href="mailto:info@autopremium.ro" class="phone-link">info@autopremium.ro</a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Schedule Card -->
                        <div class="info-card">
                            <div class="card-icon">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="card-content">
                                <h3 class="card-title">Program</h3>
                                <div class="card-text">
                                    <div class="schedule-item">
                                        <span class="days">Luni - Vineri</span>
                                        <span class="hours">09:00 - 18:00</span>
                                    </div>
                                    <div class="schedule-item">
                                        <span class="days">Sâmbătă</span>
                                        <span class="hours">10:00 - 16:00</span>
                                    </div>
                                    <div class="schedule-item">
                                        <span class="days">Duminică</span>
                                        <span class="hours closed">Închis</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section class="map-section py-24 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="map-title text-4xl font-bold text-gray-900 mb-6">
                    Găsește-ne Ușor
                </h2>
                <p class="map-subtitle text-gray-600 text-xl max-w-3xl mx-auto leading-relaxed">
                    Suntem situați în centrul orașului, cu acces ușor cu transportul public sau cu mașina personală. 
                    Showroom-ul nostru este deschis în fiecare zi pentru a te ajuta să găsești vehiculul perfect.
                </p>
            </div>
            
            <div class="map-container max-w-6xl mx-auto">
                <div class="map-card">
                    <div class="map-header mb-8">
                        <div class="flex items-center justify-center mb-6">
                            <div class="map-icon-wrapper">
                                <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                </svg>
                            </div>
                            <h3 class="text-2xl font-bold text-gray-900 ml-4">Hartă Interactivă</h3>
                        </div>
                        <p class="text-gray-600 text-center text-lg">
                            Aici va fi afișată harta cu locația noastră pentru a te ajuta să ne găsești ușor
                        </p>
                    </div>
                    
                    <div class="map-placeholder bg-white rounded-2xl p-12 shadow-lg border border-gray-200 mb-8">
                        <div class="flex items-center justify-center h-64 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border-2 border-dashed border-gray-300">
                            <div class="text-center">
                                <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m-6 3l6-3"></path>
                                </svg>
                                <p class="text-gray-500 font-medium">Hartă Interactivă</p>
                                <p class="text-gray-400 text-sm mt-2">Integrare cu Google Maps</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="map-content text-center">
                        <a href="#" class="map-button">
                            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                            </svg>
                            Deschide în Google Maps
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection 
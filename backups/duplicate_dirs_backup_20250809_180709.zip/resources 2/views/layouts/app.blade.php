<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Auto Premium')</title>
    <meta name="description" content="@yield('description', 'Auto Premium - Dealer auto de încredere')">
    @stack('head')
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS & Icons -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-icons.css') }}">

    <!-- Global minimal styles (reset + tokens + base) -->
    <link rel="stylesheet" href="{{ asset('css/reset.css') }}">
    <link rel="stylesheet" href="{{ asset('css/tokens.css') }}">
    <link rel="stylesheet" href="{{ asset('css/base.css') }}">

    <!-- Shared component styles -->
    <link rel="stylesheet" href="{{ asset('css/components/navigation.css') }}">
    <link rel="stylesheet" href="{{ asset('css/components/footer.css') }}">

    <!-- Route/page specific styles -->
    @stack('styles')
</head>
<body class="@yield('page-class')">
    <!-- Navigation -->
    <nav class="ap-navbar">
        <div class="container ap-navbar-container">
            <a href="{{ route('home') }}" class="navbar-brand">
                <span class="ap">AP</span><span class="tech">TECH</span>
            </a>
            
            <div class="ap-nav">
            <a href="{{ route('home') }}" class="ap-nav-link {{ request()->routeIs('home') ? 'active' : '' }}">
                    Acasă
                </a>
            <a href="{{ route('catalog') }}" class="ap-nav-link {{ request()->routeIs('vehicles.*') || request()->routeIs('catalog') ? 'active' : '' }}">
                    Catalog
                </a>
                <a href="{{ route('about') }}" class="ap-nav-link {{ request()->routeIs('about') ? 'active' : '' }}">
                    Despre
                </a>
                <a href="{{ route('contact') }}" class="ap-nav-link {{ request()->routeIs('contact') ? 'active' : '' }}">
                    Contact
                </a>
            <a href="{{ route('catalog') }}" class="ap-nav-cta">
                    Vezi Catalogul
                </a>
            </div>

            <button class="ap-mobile-menu-btn" id="mobile-menu-button">
                <i class="bi bi-list"></i>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div class="ap-mobile-menu" id="mobile-menu">
            <a href="{{ route('home') }}" class="ap-nav-link {{ request()->routeIs('home') ? 'active' : '' }}">
                Acasă
            </a>
            <a href="{{ route('catalog') }}" class="ap-nav-link {{ request()->routeIs('vehicles.*') || request()->routeIs('catalog') ? 'active' : '' }}">
                Catalog
            </a>
            <a href="{{ route('about') }}" class="ap-nav-link {{ request()->routeIs('about') ? 'active' : '' }}">
                Despre
            </a>
            <a href="{{ route('contact') }}" class="ap-nav-link {{ request()->routeIs('contact') ? 'active' : '' }}">
                Contact
            </a>
            <a href="{{ route('catalog') }}" class="ap-nav-cta">
                Vezi Catalogul
            </a>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        @yield('content')
    </main>

    <!-- Footer Component -->
    <x-footer />

    <!-- Navigation JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const backToTopBtn = document.getElementById('back-to-top');
            
            // Mobile Menu Toggle
            mobileMenuBtn.addEventListener('click', function() {
                mobileMenu.classList.toggle('active');
                mobileMenuBtn.classList.toggle('active');
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', function(event) {
                if (!event.target.closest('.ap-navbar')) {
                    mobileMenu.classList.remove('active');
                    mobileMenuBtn.classList.remove('active');
                }
            });

            // Back to Top functionality
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    backToTopBtn.classList.add('visible');
                } else {
                    backToTopBtn.classList.remove('visible');
                }
            });

            backToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Newsletter form handling
            const newsletterForm = document.querySelector('.newsletter-form');
            if (newsletterForm) {
                newsletterForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const email = this.querySelector('input[type="email"]').value;
                    
                    // Here you can add AJAX call to handle newsletter subscription
                    alert('Mulțumim pentru abonare! Vei primi noutățile în curând.');
                    this.reset();
                });
            }
        });
    </script>

    @stack('scripts')
    <script>
      window.apTrack = function(eventName, payload) {
        try { console.debug('[apTrack]', eventName, payload || {}); } catch (_) {}
        if (window.apAnalytics && typeof window.apAnalytics.track === 'function') {
          window.apAnalytics.track(eventName, payload || {});
        }
      };
      document.addEventListener('click', function(e){
        const el = e.target.closest('[data-analytics]');
        if (!el) return;
        const name = el.getAttribute('data-analytics');
        let payload = {};
        try { payload = JSON.parse(el.getAttribute('data-analytics-payload') || '{}'); } catch(_){ payload = {}; }
        window.apTrack(name, payload);
      });
    </script>
</body>
</html>
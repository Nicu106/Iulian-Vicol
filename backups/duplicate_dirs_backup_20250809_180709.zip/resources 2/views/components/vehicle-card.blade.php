<div class="vehicle-card">
    <!-- Image Section with Badge -->
    <div class="card-image">
        @if($vehicle->primaryImage)
            <img src="{{ $vehicle->primaryImage->image_url }}" 
                 alt="{{ $vehicle->title }}" 
                 class="card-img"
                 loading="lazy">
        @else
            <div class="card-placeholder">
                <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
            </div>
        @endif
        
        <!-- Status Badge -->
        <div class="card-badge">
            <span class="badge-text">Disponibil</span>
        </div>
        
        <!-- Quick Actions -->
        <div class="card-actions">
            <button class="action-btn favorite-btn" title="Adaugă la favorite">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                </svg>
            </button>
        </div>
    </div>

    <!-- Content Section -->
    <div class="card-content">
        <!-- Header with Brand & Model -->
        <div class="card-header">
            <div class="card-title">
                <h3 class="card-brand">{{ $vehicle->brand }}</h3>
                <h4 class="card-model">{{ $vehicle->model }}</h4>
            </div>
            <div class="card-year-badge">
                <span class="year-text">{{ $vehicle->year }}</span>
            </div>
        </div>
        
        <!-- Key Specifications -->
        <div class="card-specs">
            <div class="spec-item">
                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
                <span class="spec-text">{{ $vehicle->engine_size ?? 'N/A' }}L</span>
            </div>
            <div class="spec-item">
                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>
                </svg>
                <span class="spec-text">{{ $vehicle->fuel_type }}</span>
            </div>
            <div class="spec-item">
                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4"></path>
                </svg>
                <span class="spec-text">{{ $vehicle->transmission ?? 'Manual' }}</span>
            </div>
        </div>
        
        <!-- Mileage Info -->
        <div class="card-mileage">
            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m-6 3l6-3"></path>
            </svg>
            <span class="mileage-text">{{ $vehicle->formatted_mileage }} km</span>
        </div>
        
        <!-- Price Section -->
        <div class="card-price-section">
            <div class="price-info">
                <span class="price-amount">{{ $vehicle->formatted_price }}</span>
                <span class="price-label">Preț Final</span>
            </div>
            <div class="price-details">
                <span class="price-note">Fără taxe suplimentare</span>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="card-buttons">
            <button class="card-btn-details" onclick="openVehicleDetails('{{ $vehicle->id }}')">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                </svg>
                <span>Detalii</span>
            </button>
            
            <a href="{{ route('vehicles.show', $vehicle->slug) }}" class="card-btn-purchase">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m6 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"></path>
                </svg>
                <span>Cumpără</span>
            </a>
        </div>
    </div>
</div> 
@php /** @var \Illuminate\Pagination\LengthAwarePaginator $vehicles */ @endphp
<div class="vehicle-grid">
@foreach($vehicles as $vehicle)
  <div class="vehicle-grid-item">
    <div class="vehicle-card">
      <div class="vehicle-image-container">
        <img src="{{ $vehicle->primaryImage?->image_url ?? 'https://via.placeholder.com/300x200?text=No+Image' }}" alt="{{ $vehicle->title }}" class="vehicle-image">
        @if($vehicle->is_featured)
          <div class="vehicle-badge"><i class="bi bi-star-fill"></i> Featured</div>
        @endif
        @if($vehicle->is_available)
          <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-success);">
            <i class="bi bi-check-circle"></i> Disponibil
          </div>
        @else
          <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-secondary);">
            <i class="bi bi-x-circle"></i> Vândut
          </div>
        @endif
      </div>
      <div class="vehicle-content">
        <h5 class="vehicle-title">{{ $vehicle->title }}</h5>
        <div class="vehicle-price">{{ $vehicle->formatted_price }}</div>
        <div class="vehicle-details">
          <div class="vehicle-detail">
            <i class="bi bi-calendar"></i>
            <div class="vehicle-detail-label">An</div>
            <div class="vehicle-detail-value">{{ $vehicle->year }}</div>
          </div>
          <div class="vehicle-detail">
            <i class="bi bi-speedometer2"></i>
            <div class="vehicle-detail-label">Km</div>
            <div class="vehicle-detail-value">{{ $vehicle->formatted_mileage }}</div>
          </div>
          <div class="vehicle-detail">
            <i class="bi bi-fuel-pump"></i>
            <div class="vehicle-detail-label">Combustibil</div>
            <div class="vehicle-detail-value">{{ $vehicle->fuel_type }}</div>
          </div>
        </div>
        @if($vehicle->features)
          <div class="vehicle-features">
            @foreach(array_slice($vehicle->features, 0, 3) as $feature)
              <span class="feature-tag">{{ $feature }}</span>
            @endforeach
            @if(count($vehicle->features) > 3)
              <span class="feature-tag">+{{ count($vehicle->features) - 3 }} mai multe</span>
            @endif
          </div>
        @endif
        <div class="vehicle-actions">
          <a href="{{ route('vehicles.show', $vehicle) }}" class="btn-view-details"><i class="bi bi-eye"></i> Vezi Detalii</a>
          <button class="btn-favorite" onclick="toggleFavorite({{ $vehicle->id }})"><i class="bi bi-heart"></i></button>
        </div>
      </div>
    </div>
  </div>
@endforeach
</div>


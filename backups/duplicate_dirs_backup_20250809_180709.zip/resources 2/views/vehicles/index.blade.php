@extends('layouts.app')

@section('title', 'Catalog Auto - Auto Premium')
@section('description', 'Descoperă catalogul nostru complet de vehicule. Filtrează după marcă, preț, an și multe altele.')

@push('styles')
<link rel="stylesheet" href="{{ asset('css/pages/catalog.css') }}">
@endpush

@section('page-class', 'page-catalog')

@section('content')
    <!-- Debug Section -->
    <div class="container mt-4">
        <div class="alert alert-info">
            <strong>Debug Info:</strong> 
            Vehicule în baza de date: {{ $vehicles->count() }} | 
            Total: {{ $vehicles->total() }} |
            Pagina: {{ $vehicles->currentPage() }}
        </div>
    </div>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">
                    La Noi Găsești Orice
                </h1>
                <p class="hero-subtitle">
                    De la mașini de oraș la SUV-uri de lux, avem exact ce cauți
                </p>
            </div>
        </div>
    </section>

    <!-- Catalog Section -->
    <section class="catalog-section">
        <div class="container">
            <div class="catalog-container">
                <!-- Left Sidebar - Advanced Filters -->
                <div class="catalog-filters">
                    <aside class="filters-sidebar">
                        <div class="filters-header">
                            <h3 class="filters-title">Filtre Avansate</h3>
                            <button id="clear-filters" class="btn-reset">
                                <i class="bi bi-arrow-clockwise"></i> Resetează
                            </button>
                        </div>

                        <form id="vehicle-filters">
                            <!-- Brand Filter -->
                            <div class="filter-group">
                                <label class="filter-label">Marcă</label>
                                <select name="brands[]" class="form-select" multiple>
                                    @foreach($brands as $brand)
                                        <option value="{{ $brand }}" 
                                                {{ in_array($brand, request('brands', [])) ? 'selected' : '' }}>
                                            {{ $brand }}
                                        </option>
                                    @endforeach
                                </select>
                                <div class="filter-chips" id="brand-chips"></div>
                            </div>

                            <!-- Price Range -->
                            <div class="filter-group">
                                <label class="filter-label">Preț (€)</label>
                                <div class="price-range">
                                    <input type="number" name="min_price" placeholder="Min" 
                                           value="{{ request('min_price') }}" class="form-control">
                                    <span class="price-separator">-</span>
                                    <input type="number" name="max_price" placeholder="Max" 
                                           value="{{ request('max_price') }}" class="form-control">
                                </div>
                            </div>

                            <!-- Year Range -->
                            <div class="filter-group">
                                <label class="filter-label">An</label>
                                <div class="year-range">
                                    <select name="min_year" class="form-select">
                                        <option value="">De la</option>
                                        @for($year = date('Y'); $year >= 1990; $year--)
                                            <option value="{{ $year }}" {{ request('min_year') == $year ? 'selected' : '' }}>
                                                {{ $year }}
                                            </option>
                                        @endfor
                                    </select>
                                    <select name="max_year" class="form-select">
                                        <option value="">Până la</option>
                                        @for($year = date('Y'); $year >= 1990; $year--)
                                            <option value="{{ $year }}" {{ request('max_year') == $year ? 'selected' : '' }}>
                                                {{ $year }}
                                            </option>
                                        @endfor
                                    </select>
                                </div>
                            </div>

                            <!-- Fuel Type -->
                            <div class="filter-group">
                                <label class="filter-label">Combustibil</label>
                                <select name="fuel_type" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Benzină" {{ request('fuel_type') == 'Benzină' ? 'selected' : '' }}>Benzină</option>
                                    <option value="Diesel" {{ request('fuel_type') == 'Diesel' ? 'selected' : '' }}>Diesel</option>
                                    <option value="Electric" {{ request('fuel_type') == 'Electric' ? 'selected' : '' }}>Electric</option>
                                    <option value="Hibrid" {{ request('fuel_type') == 'Hibrid' ? 'selected' : '' }}>Hibrid</option>
                                </select>
                            </div>

                            <!-- Transmission -->
                            <div class="filter-group">
                                <label class="filter-label">Transmisie</label>
                                <select name="transmission" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Manuală" {{ request('transmission') == 'Manuală' ? 'selected' : '' }}>Manuală</option>
                                    <option value="Automată" {{ request('transmission') == 'Automată' ? 'selected' : '' }}>Automată</option>
                                </select>
                            </div>

                            <!-- Vehicle Type -->
                            <div class="filter-group">
                                <label class="filter-label">Tip Vehicul</label>
                                <select name="vehicle_type" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="SUV" {{ request('vehicle_type') == 'SUV' ? 'selected' : '' }}>SUV</option>
                                    <option value="Sedan" {{ request('vehicle_type') == 'Sedan' ? 'selected' : '' }}>Sedan</option>
                                    <option value="Hatchback" {{ request('vehicle_type') == 'Hatchback' ? 'selected' : '' }}>Hatchback</option>
                                    <option value="Break" {{ request('vehicle_type') == 'Break' ? 'selected' : '' }}>Break</option>
                                    <option value="Coupe" {{ request('vehicle_type') == 'Coupe' ? 'selected' : '' }}>Coupe</option>
                                </select>
                            </div>

                            <!-- Color -->
                            <div class="filter-group">
                                <label class="filter-label">Culoare</label>
                                <select name="color" class="form-select">
                                    <option value="">Toate</option>
                                    <option value="Alb" {{ request('color') == 'Alb' ? 'selected' : '' }}>Alb</option>
                                    <option value="Negru" {{ request('color') == 'Negru' ? 'selected' : '' }}>Negru</option>
                                    <option value="Gri" {{ request('color') == 'Gri' ? 'selected' : '' }}>Gri</option>
                                    <option value="Albastru" {{ request('color') == 'Albastru' ? 'selected' : '' }}>Albastru</option>
                                    <option value="Roșu" {{ request('color') == 'Roșu' ? 'selected' : '' }}>Roșu</option>
                                    <option value="Verde" {{ request('color') == 'Verde' ? 'selected' : '' }}>Verde</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Aplică Filtrele
                            </button>
                        </form>
                    </aside>
                </div>

                <!-- Right Content - Vehicle Grid -->
                <div class="catalog-content">
                    <!-- Results Header -->
                    <div class="results-header">
                        <div>
                            <div class="results-count">{{ $vehicles->count() }} vehicule găsite</div>
                            <div class="results-subtitle">Rezultate pentru criteriile tale de căutare</div>
                        </div>
                         <div>
                             <select class="form-select sort-select">
                                 <option value="newest" {{ request('sort')=='newest' ? 'selected' : '' }}>Cele mai noi</option>
                                 <option value="oldest" {{ request('sort')=='oldest' ? 'selected' : '' }}>Cele mai vechi</option>
                                 <option value="price_asc" {{ request('sort')=='price_asc' ? 'selected' : '' }}>Preț crescător</option>
                                 <option value="price_desc" {{ request('sort')=='price_desc' ? 'selected' : '' }}>Preț descrescător</option>
                             </select>
                         </div>
                    </div>

                    <!-- Vehicle Grid -->
                    <div class="vehicle-grid">
                        @foreach($vehicles as $vehicle)
                            <div class="vehicle-grid-item">
                                <div class="vehicle-card">
                                    <div class="vehicle-image-container">
                                        <img src="{{ $vehicle->primaryImage?->image_url ?? 'https://via.placeholder.com/300x200?text=No+Image' }}" 
                                             alt="{{ $vehicle->title }}" class="vehicle-image">
                                        
                                        @if($vehicle->is_featured)
                                            <div class="vehicle-badge">
                                                <i class="bi bi-star-fill"></i> Featured
                                            </div>
                                        @endif
                                        
                                        @if($vehicle->is_available)
                                            <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-success);">
                                                <i class="bi bi-check-circle"></i> Disponibil
                                            </div>
                                        @else
                                            <div class="vehicle-badge" style="top: 3rem; background: var(--gradient-secondary);">
                                                <i class="bi bi-x-circle"></i> Vândut
                                            </div>
                                        @endif
                                    </div>
                                    
                                    <div class="vehicle-content">
                                        <h5 class="vehicle-title">{{ $vehicle->title }}</h5>
                                        <div class="vehicle-price">{{ $vehicle->formatted_price }}</div>
                                        
                                        <div class="vehicle-details">
                                            <div class="vehicle-detail">
                                                <i class="bi bi-calendar"></i>
                                                <div class="vehicle-detail-label">An</div>
                                                <div class="vehicle-detail-value">{{ $vehicle->year }}</div>
                                            </div>
                                            <div class="vehicle-detail">
                                                <i class="bi bi-speedometer2"></i>
                                                <div class="vehicle-detail-label">Km</div>
                                                <div class="vehicle-detail-value">{{ $vehicle->formatted_mileage }}</div>
                                            </div>
                                            <div class="vehicle-detail">
                                                <i class="bi bi-fuel-pump"></i>
                                                <div class="vehicle-detail-label">Combustibil</div>
                                                <div class="vehicle-detail-value">{{ $vehicle->fuel_type }}</div>
                                            </div>
                                        </div>

                                        @if($vehicle->features)
                                            <div class="vehicle-features">
                                                @foreach(array_slice($vehicle->features, 0, 3) as $feature)
                                                    <span class="feature-tag">{{ $feature }}</span>
                                                @endforeach
                                                @if(count($vehicle->features) > 3)
                                                    <span class="feature-tag">+{{ count($vehicle->features) - 3 }} mai multe</span>
                                                @endif
                                            </div>
                                        @endif

                                        <div class="vehicle-actions">
                                            <a href="{{ route('vehicles.show', $vehicle) }}" class="btn-view-details">
                                                <i class="bi bi-eye"></i> Vezi Detalii
                                            </a>
                                            <button class="btn-favorite" onclick="toggleFavorite({{ $vehicle->id }})">
                                                <i class="bi bi-heart"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>

                    <!-- Pagination -->
                    @if($vehicles->hasPages())
                        <div class="d-flex justify-content-center mt-4">
                            {{ $vehicles->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection

@push('scripts')
<script>
// Advanced Filter Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit form when filters change
    const filterForm = document.getElementById('vehicle-filters');
    const filterInputs = filterForm.querySelectorAll('input, select');
    
    filterInputs.forEach(input => {
        input.addEventListener('change', function() {
            setTimeout(() => {
                filterForm.submit();
            }, 500);
        });
    });

    // Clear filters functionality
    const clearFiltersBtn = document.getElementById('clear-filters');
    clearFiltersBtn.addEventListener('click', function() {
        window.location.href = '{{ route("vehicles.index") }}';
    });

    // Sort functionality
    const sortSelect = document.querySelector('.sort-select');
    sortSelect.addEventListener('change', function() {
        const url = new URL(window.location);
        url.searchParams.set('sort', this.value);
        window.location = url;
    });

    // Filter chips functionality
    updateFilterChips();
});

function updateFilterChips() {
    const urlParams = new URLSearchParams(window.location.search);
    const chipsContainer = document.getElementById('brand-chips');
    
    if (chipsContainer) {
        chipsContainer.innerHTML = '';
        
        const brands = urlParams.getAll('brands[]');
        brands.forEach(brand => {
            const chip = document.createElement('div');
            chip.className = 'filter-chip';
            chip.innerHTML = `
                ${brand}
                <button class="remove-chip" onclick="removeFilter('brands[]', '${brand}')">
                    <i class="bi bi-x"></i>
                </button>
            `;
            chipsContainer.appendChild(chip);
        });
    }
}

function removeFilter(param, value) {
    const url = new URL(window.location);
    const values = url.searchParams.getAll(param);
    const newValues = values.filter(v => v !== value);
    
    url.searchParams.delete(param);
    newValues.forEach(v => url.searchParams.append(param, v));
    
    window.location = url;
}

function toggleFavorite(vehicleId) {
    // Add favorite functionality
    const btn = event.target.closest('.btn-favorite');
    const icon = btn.querySelector('i');
    
    if (icon.classList.contains('bi-heart')) {
        icon.classList.remove('bi-heart');
        icon.classList.add('bi-heart-fill');
        btn.style.background = 'var(--gradient-secondary)';
    } else {
        icon.classList.remove('bi-heart-fill');
        icon.classList.add('bi-heart');
        btn.style.background = 'var(--gradient-primary)';
    }
}
</script>
@endpush 
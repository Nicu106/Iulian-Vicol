@extends('layouts.app')

@section('title', 'Auto Premium - Dealer Auto de Încredere')
@section('description', 'Auto Premium - Dealer auto cu peste 15 ani de experiență în industria auto românească. Oferim mașini de calitate și service tehnic profesionist.')

@section('page-class', 'page-home')

@section('content')
<div class="container py-5">
  <h1 class="h3">Acasă</h1>
  <p>Conținutul va fi adăugat ulterior.</p>
</div>
@endsection
<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Vehicle::with('primaryImage')->available();

        // Brands (single or multiple)
        if ($request->filled('brand')) {
            $query->where('brand', $request->string('brand'));
        }
        if ($request->filled('brands')) {
            $brands = array_filter((array) $request->input('brands'));
            if (count($brands)) {
                $query->whereIn('brand', $brands);
            }
        }

        // Price range
        $minPrice = $request->input('min_price');
        $maxPrice = $request->input('max_price');
        if ($minPrice !== null || $maxPrice !== null) {
            if ($minPrice !== null) { $query->where('price', '>=', (float) $minPrice); }
            if ($maxPrice !== null) { $query->where('price', '<=', (float) $maxPrice); }
        }

        // Year range
        $minYear = $request->input('min_year');
        $maxYear = $request->input('max_year');
        if ($minYear !== null) { $query->where('year', '>=', (int) $minYear); }
        if ($maxYear !== null) { $query->where('year', '<=', (int) $maxYear); }
        if ($request->filled('year')) { $query->where('year', (int) $request->input('year')); }

        // Fuel, transmission, type, color
        if ($request->filled('fuel_type')) { $query->where('fuel_type', $request->string('fuel_type')); }
        if ($request->filled('transmission')) { $query->where('transmission', $request->string('transmission')); }
        if ($request->filled('vehicle_type')) { $query->where('vehicle_type', $request->string('vehicle_type')); }
        if ($request->filled('color')) { $query->where('color', $request->string('color')); }

        // Keyword search
        if ($request->filled('q')) {
            $q = $request->string('q');
            $query->where(function ($sub) use ($q) {
                $sub->where('title', 'like', "%{$q}%")
                    ->orWhere('brand', 'like', "%{$q}%")
                    ->orWhere('model', 'like', "%{$q}%");
            });
        }

        // Sorting
        switch ($request->input('sort')) {
            case 'oldest':
                $query->orderBy('created_at', 'asc');
                break;
            case 'price_asc':
                $query->orderBy('price', 'asc');
                break;
            case 'price_desc':
                $query->orderBy('price', 'desc');
                break;
            case 'newest':
            default:
                $query->orderBy('created_at', 'desc');
                break;
        }

        $vehicles = $query->paginate(24)->appends($request->query());

        // Brands for filter
        $brands = Vehicle::available()->distinct()->pluck('brand')->sort();

        return view('vehicles.index', compact('vehicles', 'brands'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Vehicle $vehicle)
    {
        $vehicle->load('images');
        
        // Get related vehicles
        $relatedVehicles = Vehicle::with('primaryImage')
            ->where('id', '!=', $vehicle->id)
            ->where('brand', $vehicle->brand)
            ->available()
            ->take(4)
            ->get();

        return view('vehicles.show', compact('vehicle', 'relatedVehicles'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Get vehicles for AJAX requests (filtering)
     */
    public function getVehicles(Request $request)
    {
        $query = Vehicle::with('primaryImage')->available();

        if ($request->filled('brand')) { $query->where('brand', $request->string('brand')); }
        if ($request->filled('brands')) { $query->whereIn('brand', (array) $request->input('brands')); }
        if ($request->filled('min_price')) { $query->where('price', '>=', (float) $request->input('min_price')); }
        if ($request->filled('max_price')) { $query->where('price', '<=', (float) $request->input('max_price')); }
        if ($request->filled('min_year')) { $query->where('year', '>=', (int) $request->input('min_year')); }
        if ($request->filled('max_year')) { $query->where('year', '<=', (int) $request->input('max_year')); }
        if ($request->filled('fuel_type')) { $query->where('fuel_type', $request->string('fuel_type')); }
        if ($request->filled('transmission')) { $query->where('transmission', $request->string('transmission')); }

        switch ($request->input('sort')) {
            case 'oldest': $query->orderBy('created_at', 'asc'); break;
            case 'price_asc': $query->orderBy('price', 'asc'); break;
            case 'price_desc': $query->orderBy('price', 'desc'); break;
            case 'newest': default: $query->orderBy('created_at', 'desc'); break;
        }

        $vehicles = $query->paginate(12)->appends($request->query());

        return response()->json([
            'vehicles' => $vehicles,
            'html' => view('vehicles.partials.grid', compact('vehicles'))->render()
        ]);
    }
}
